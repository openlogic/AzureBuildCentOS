#include "hyperv_vmbus.h"

#define CREATE_TRACE_POINTS
#include "hv_trace.h"
